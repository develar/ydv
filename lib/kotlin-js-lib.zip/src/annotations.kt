package js;

native
public annotation class native(name: String = "")
native
public annotation class library(name: String = "")
native
public annotation class enumerable()
